<?php header('Access-Control-Allow-Origin: *');

  include 'index.php';
  include 'lib.php';
  session_start();

  // Due to unresolvable Error 405, I had to use the $_GET rather thatn $_POST - it was not allowing $_POST in any situation.

  if(isset($_GET['username'], $_GET['password'])){
    $username = $_GET['username'];
    $password = $_GET['password'];
    $result = checkStaffLogin($username, $password);
    $count = mysqli_num_rows($result);
    if($count==1){
      session_register("username");
      $_SESSION['username'] = "username";
      header("location: staff.php");
    }else{
      $result = checkAthleteLogin($username, $password);
      $count = mysqli_num_rows($result);
      if($count == 1){
        session_register("username");
        $_SESSION['username'] = "username";
        header("location: athlete.php");
      }else{
        unset($_GET['username']);
        unset($_GET['password']);
        header("location: login.php");
      }
    }
  }

  function checkStaffLogin($email, $password){
    $password = sha1($password);
    $db = getDBConnection();
    $sql = "SELECT * from `staff` where `email` = '$email'";
    if($db != null){
      $res = $db->query($sql);
      if($res && $row->fetch_assoc())
        if($row[`password`] == $password) return $row;
    }
    return null;
  }

  function checkAthleteLogin($email, $password){
    $password = sha1($password);
    $db = getDBConnection();
    $sql = "SELECT * from `athlete` where `email` = '$email'";
    if($db != null){
      $res = $db->query($sql);
      if($res && $row->fetch_assoc())
        if($row[`password`] == $password) return $row;
    }
    return null;
  }
?>

-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2016 at 03:18 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `muscle-mgmt`
--

-- --------------------------------------------------------

--
-- Table structure for table `athlete`
--

CREATE TABLE `athlete` (
  `id` int(11) NOT NULL,
  `fname` varchar(128) NOT NULL,
  `lname` varchar(128) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phoneNo` int(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `membershipNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `athlete`
--

INSERT INTO `athlete` (`id`, `fname`, `lname`, `address`, `phoneNo`, `email`, `password`, `membershipNo`) VALUES
(1, 'Jonathan', 'Jones', '12 Lane Lane', 1478958, 'jjones@live.com', 'b3daa77b4c04a9551b8781d03191fe098f325e67', 1),
(2, 'Maya', 'Faizal', '7 Bayside', 4879513, 'mfaiz@unicef.org', 'a1881c06eec96db9901c7bbfe41c42a3f08e9cb4', 2),
(3, 'John', 'Doe', '6 Nowhere Blvd', 7895132, 'jdoe@gmail.com', '0b7f849446d3383546d15a480966084442cd2193', 3);

-- --------------------------------------------------------

--
-- Table structure for table `daysleft`
--

CREATE TABLE `daysleft` (
  `membershipId` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `remainder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daysleft`
--

INSERT INTO `daysleft` (`membershipId`, `type`, `remainder`) VALUES
(2, 2, 3),
(3, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE `membership` (
  `id` int(11) NOT NULL,
  `type` varchar(128) NOT NULL,
  `barcodeNo` int(64) NOT NULL,
  `active` varchar(128) NOT NULL,
  `startDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membership`
--

INSERT INTO `membership` (`id`, `type`, `barcodeNo`, `active`, `startDate`, `endDate`) VALUES
(1, '1', 12345, 'yes', '2016-11-23 04:00:00', '2016-12-23 04:00:00'),
(2, '2', 45678, 'yes', '2016-11-29 04:00:00', '2016-12-29 04:00:00'),
(3, '2', 45796, 'no', '2016-11-27 04:00:00', '2016-12-27 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `paymentMethod` varchar(64) NOT NULL,
  `membershipId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `date`, `paymentMethod`, `membershipId`) VALUES
(1, '2016-11-23 04:00:00', 'Cash', 1),
(2, '2016-10-29 04:00:00', 'Linx', 2),
(3, '2016-11-29 04:00:00', 'Linx', 2),
(4, '2016-11-27 04:00:00', 'Credit', 3);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `fname` varchar(128) NOT NULL,
  `lname` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNo` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `fname`, `lname`, `email`, `password`, `phoneNo`, `role`) VALUES
(1, 'Rodney', 'Vire', 'rodneysrevolution@gmail.com', '6c7ca345f63f835cb353ff15bd6c5e052ec08e7a', 6244348, 'Owner1'),
(2, 'Christine', 'Jones-Vire', 'cjvire@gmail.com', '315f166c5aca63a157f7d41007675cb44a948b33', 7891531, 'Owner2'),
(3, 'Karen-Lisa', 'Garcia', 'klg@yahoo.com', '33aab3c7f01620cade108f488cfd285c0e62c1ec', 4678915, 'FrontDesk1');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `price` int(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `name`, `price`) VALUES
(1, 'monthly', 500),
(2, 'sixClass', 350),
(3, 'twelveClass', 450);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `athlete`
--
ALTER TABLE `athlete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daysleft`
--
ALTER TABLE `daysleft`
  ADD PRIMARY KEY (`membershipId`,`type`);

--
-- Indexes for table `membership`
--
ALTER TABLE `membership`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `athlete`
--
ALTER TABLE `athlete`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `membership`
--
ALTER TABLE `membership`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

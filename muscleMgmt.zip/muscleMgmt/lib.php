<?php
function getDBConnection(){
    try{ // Uses try and catch to handle any unforeseen errors
        $db = new mysqli("localhost", "root", "", "muscle-mgmt");
        if ($db->connect_errno > 0)return null;
        return $db;
    }catch(Exception $e){ } //Catch currently does nothing
    return null;
}

// used for all basic functionality in this app
function getAllAthletes(){
  $db = getDBConnection();
  $athletes = [];
  if($db != null){
    $sql = "SELECT * from `athlete` a, `membership` m where a.membershipNo = m.id";
    $res = $db->query($sql);
    while($res && $row = $res->fetch_assoc()){
      $athletes[] = $row;
    }
    $db->close();
  }
  return $athletes;
  }

?>

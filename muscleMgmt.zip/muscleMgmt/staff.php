<?php
  session_start();
  if (isset($_SESSION['email']) && isset($_SESSION['password'])){
  	$email = $_SESSION['email'];
  	$password = $_SESSION['password'];
  }

  header('Content-type: text/html');
  header('Access-Control-Allow-Origin: *');
 ?>

 <!DOCTYPE html>
 <!--suppress HtmlUnknownTarget -->
 <html lang="en">
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
 	<meta name="description" content="">
 	<meta name="author" content="">

 	<title>Muscle Management</title>

 	<!-- Bootstrap core CSS -->
 	<link href="bower_components/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
 	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
 	<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet">

   <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 	<link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
 	<!-- Custom styles for this template -->
   <link href="css/spacelab.css" rel="stylesheet">
 </head>

 <body>

 <div class="container">
 	<div class="header clearfix">

 		<div class="jumbotron" style="text-align: center;">
 			<h1 class="app-name"><strong>Muscle Management</strong></h1>
 		</div>

    <div class="container" ng-app="main-muscle-staff">
      <div ng-view></div>
   	</div>

 	<!-- <footer class="footer" style="position: absolute; bottom: 0;">
 		<p>&copy; Karin Singh 2016</p>
 	</footer> -->
  </div>
 </div> <!-- /container -->

 <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 <script src="js/ie10-viewport-bug-workaround.js"></script>
 <script src="bower_components/jquery/dist/jquery.js"></script>
 <script src="bower_components/bootstrap/js/dropdown.js"></script>
 <script src="bower_components/angular/angular.min.js"></script>
 <script src="bower_components/angular-route/angular-route.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
 <script src="js/main.js"></script>
 </body>
 </html>

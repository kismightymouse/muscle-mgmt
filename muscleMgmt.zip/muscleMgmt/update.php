<?php
    if(isset($_GET['action'])){
      $db = getDBConnection();
      if($db != null){
        $sql = "UPDATE `membership` set `active` = 'yes' where `membership`.`id` = $_GET['action']";
        $res = $db->query($sql);
        return $res;
      }
      $db->close();
      return null;
    }
 ?>

<?php
  include 'index.php';
  include 'lib.php';
  session_start();
if(isset($_POST['val']) && !empty($_POST['search'])){
  $searchField = $_POST['val'];
  $searchParam = $_POST['search'];
  $row = search($searchField, $searchParam);
}

function search($field, $param){
  $db = getDBConnection();
  if($field == 'fname') $sql = "SELECT * from `athlete` a and `membership` m where a.membershipNo = m.id and a.fname = '$param'";
  else{
    if($field == 'lname') $sql = "SELECT * from `athlete` a and `membership` m where a.membershipNo = m.id and a.lname = '$param'";
    else{
      if($field == 'barcode') $sql = "SELECT * from `athlete` a and `membership` m where a.membershipNo = m.id and m.barcodeNo = $param";
      else $sql = "SELECT * from `athlete` a and `membership` m where a.membershipNo = m.id and a.email = '$param'";
    }
  }
  if($db != null){
    $res = $db->query($sql);
    if($res && $row->fetch_assoc())
      return $row;
  }
  return null;
}
?>

console.log("Successfully loaded JavaScript");

'use strict';

var base_url = "index.php"; //base url of db

$(document).ready(function(){
  console.log("Page is loaded and ready");
  retrieveAthletes();
});

function retrieveAthletes(){
  console.log("Attempting to retrieve athletes to update end dates");
  $.get(base_url+"/athlete", processAllAthletes, "json"); //As soon as page loads, check which athletes have expired memberships (by date)
}

function processAllAthletes(res){
  console.log("Updating all expired memberships");
  var today;
  today = new Date();
  today = today.getUTCFullYear() + '-' +
    ('00' + (today.getUTCMonth()+1)).slice(-2) + '-' +
    ('00' + today.getUTCDate()).slice(-2) + ' ' +
    ('00' + today.getUTCHours()).slice(-2) + ':' +
    ('00' + today.getUTCMinutes()).slice(-2) + ':' +
    ('00' + today.getUTCSeconds()).slice(-2);
    // console.log(today);
  res.forEach(function(athlete){
    if(athlete['endDate'] < today){
      var set = {'active': "no"};
      console.log(athlete['fname']+" is expired");
      var router = express.Router();

      router.all('*', function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "X-Requested-With");
        next();
       });
      $.post(base_url+"/athlete", set, function(res){
        console.log("Updated expired accounts");
      }, "json");
    }
  })
}

//Call to create table on view all athletes
function callTable(){
  $.get(base_url+"/athlete", createTable, "json");
}

function createTable(records){
  var sec_id = "#athTable";
  var html = $("#table_heading").html();
  records.forEach(function(el){
    html += "<tr>";
    html += "<td>"+el['fname']+"</td>";
    html += "<td>"+el['lname']+"</td>";
    html += "<td>"+el['membershipNo']+"</td>";
    if(el['active']==='yes') html += "<td>Active</td>";
    else html += "<td>Inactive</td>";
    html+="<td><button class='btn btn-primary' onclick=\"update("+el.membershipNo+")\"><i class='fa fa-gavel' aria-hidden='true'</i></button>";
    html += "</tr>";
  });
  html+="</tbody></table>";

  $(sec_id).html(html);
}

//Set the "active" field to "yes" for athlete upon clicking button
function update(rec){
  var set ={ 'active': "yes"};
  console.log(rec['fname']);
  $.ajax({
      url:'update.php',
      data: {action: rec},
      type: 'get',
      success: function(){
        swal("Updated", "Successfully updated", "success");
      }
  });
  return false;
}

function searchAth(){
  $.get(base_url+"/athlete", searchAllAthletes, "json");
}
//Search for a particular athlete - with a choice of which field to search by
function searchAllAthletes(rec){
  var field = document.getElementById("selectField").value;
  var param = document.getElementById("searchParam").value;
  var searchField;
  if(field === 'fname') searchField = "fname";
  else{
    if(field === 'lname') searchField = "lname";
    else{
      if(field === 'barcode') searchField = "barcodeNo";
      else searchField = "email";
    }
  }
  console.log(field);
  console.log(param);
  var mod_id = "#searchModal";
  var html = "<p><strong>First name:</strong> ";
  rec.forEach(function(res){
    if(res[searchField] == param){
      html+= res['fname']+"</p>";
      html+= "<p><strong>Last name:</strong> " + res['lname']+"</p>";
      html+= "<p><strong>Barcode number:</strong> " + res['barcodeNo']+"</p>";
      html+= "<p><strong>Active:</strong> ";
      if(res['active']==='yes') html += "Active</p>";
      else html += "Inactive</p>";
      html+="<td><button class='btn btn-primary' onclick=\"update("+res['membershipNo']+")\"><i class='fa fa-gavel' aria-hidden='true'</i></button>";
    }
  });
  $(mod_id).html(html);
}

//Lets an athlete view their own data by searching for their data by their email.
function searchAthLog(){
  $.get(base_url+"/athlete", searchOneAth, "json");
}

var userEmail=""; //Set from the controller

function searchOneAth(rec){
  var mod_id = "#searchModalAth";
  var html = "<p><strong>First name:</strong> ";
  rec.forEach(function(res){
    if(res['email']==userEmail){
      html+= res['fname']+"</p>";
      html+= "<p><strong>Last name:</strong> " + res['lname']+"</p>";
      html+= "<p><strong>Barcode number:</strong> " + res['barcodeNo']+"</p>";
      html+= "<p><strong>Active:</strong> ";
      if(res['active']==='yes') html += "Active</p>";
      else html += "<p>Inactive</p>";
    }
  });
  $(mod_id).html(html);
}


// I've tried hard to get the charts to work and cannot work out why it isn't. Need to move on to uploading to Heroku and GitHub. Will come back to this if I have time
function startAnalyticsSetup(){
  console.log("Analytics started");
  $("#select_chart").change(changeChart);
}

function changeChart(){
  console.log("Inside 'Change Chart'");
  var choice = $(this).val();
  var $chart = $("#chart_sec");
  $chart.empty();
  $.get(base_url+"/athlete", function(data){
    if(choice == "Active vs Inactive"){
      // alert("Active vs Inactive");
      var chartData = [];
      data.forEach(function(rec){
        var chartRec = {};
        chartRec.active = rec.active;
        chartData.push(chartRec);
      });
      drawHighchart1(chartData);
    }
    // else{
    //   if(choice == "Active members by month"){
    //     drawActiveMonth($chart, data);
    //   }
    //     else{
    //       alert(choice);
    //     }
    // }
  }, "json");
}

function drawHighchart1(data){
  var ctx = document.getElementById("myChart").getContext("2d");
  var actives = {yes: 0,
                 no: 0};
  data.forEach(function(rec){
    if(rec.active == "yes") actives["yes"] += 1;
    else actives["no"] +=1;
  });
  var dataUse = {
    labels: [
      "Active",
      "Inactive"
    ],
    datasets: [{
        data: [actives["yes"], actives["no"]]
    }]
  }
  var myChart = new Chart(ctx,
    {type: 'pie',
    data: dataUse}
  );
}

//Module for the main page and athlete side
var app = angular.module("main-muscle", ['ngRoute']);
app.config(["$routeProvider",function($routeProvider) {
    $routeProvider
      .when('/', {
          controller: 'loginController',
          templateUrl: 'views/login.html'
      })
      .when('/athlete', {
          controller: 'athleteController',
          templateUrl: 'views/athlete.html'
      })
      .otherwise({ redirectTo: '/' });
}]);

app.controller('loginController', ['$scope', function($scope){
    console.log("Login Controller Executed");
    $scope.setUser = function(){
      $scope.userEmail = $scope.username;
      userEmail = $scope.userEmail;
      console.log(userEmail);
    }
}]);

app.controller('athleteController', ['$scope', function($scope){
    console.log("Athlete Controller Executed");
}]);

//Module for all Staff functions
var appStaff = angular.module("main-muscle-staff", ['ngRoute']);
appStaff.config(["$routeProvider",function($routeProvider) {
    $routeProvider
      .when('/', {
          controller: 'staffController',
          templateUrl: 'views/staff.html'
      })
      .when('/viewAll', {
          controller: 'viewAllController',
          templateUrl: 'views/viewAll.html'
      })
      .when('/searchAthlete', {
          controller: 'searchAthleteController',
          templateUrl: 'views/searchAthlete.html'
      })
      .when('/analytics', {
          controller: 'AnalyticsController',
          templateUrl: 'views/highcharts.html'
      })

      .otherwise({ redirectTo: '/' });
}]);

appStaff.controller('staffController', ['$scope', function($scope, $location){
    console.log("Staff Controller Executed");
}]);

appStaff.controller('viewAllController', ['$scope', function($scope){
    console.log("View All Controller Executed");
      callTable();
}]);

appStaff.controller('searchAthleteController', ['$scope', function($scope, $location){
    console.log("Search Athlete Controller Executed");
}]);

appStaff.controller('AnalyticsController', ['$scope', function($scope, $location){
    console.log("Analytics Controller Executed");
    startAnalyticsSetup();
}]);
